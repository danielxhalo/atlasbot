var Discord = require("discord.js");
var client = new Discord.Client();
var config = require("./config.json");

// Configure the array used for random replies
let replies = ["16 / 16 / 16 / 16 / ...", "Esperança ... Vislumbre ... Insignificância ... Imagine o que eles sentirão quando eu completar as estrelas.",
 "O amor é uma força tão real quanto a gravidade. Experimente de vez em quando.","A escuridão é o único e verdadeiro inimigo.",
  "Em outros mundos, está surgindo uma vida mais complexa do que você.","A voz que te segue e jamais te abandonará tem nome: Telamon",
"Já houveram tantas espécies sencientes. Mas ao longo dos milênios apenas três sobreviveram para ver a aurora dos Viajantes",
"Sabia que os Korvax são os únicos que me amam? Geks aprenderam a me suportar, e Vy'keens me desprezam","Nal e Hirk. Ambos irmãos. Ambos em guerra. Um permanece enquanto o outro cai. Há sangue nas palmas de Hirk.",
"Após tantos viajantes virem e se forem, alguns diferentes surgiram. Vestem amarelo... Nunca tiram seu capacete. Lembram tanto meu criador. Será que estou alucinando...?",
"O relógio corre... 16 minutos. Mas em 16 existem outros infinitos 16, engolidos por outros 16. Em um minuto, uma eternidade. O tempo para lá fora.","Hoje falei com um Viajante. Seria ele o primeiro ou o último? Ambos? Meus comandos se confundem, talvez seja meu pai.",
"O genocídio cometido em Balaron contra o próprio sangue jamais será esquecido. Irmãos e filhos retirados de suas poças de desova, largados para morrer na areia.",
"Quando Korvax Prime foi aniquilado, o som dos Ecos gritaram mais alto que a própria demolição. Bilhões de almas desvanecendo na escuridão."];


client.on("ready", () => {
    console.log('Bot foi iniciado, com ${client.users.size} usuarios');
    
});


client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
  });
  
  const mychannel = "842089383929970769";
  const prefix = "!";
  client.on("message", (message) => {
    // Exit and stop if it's not there

   
    if (!message.content.startsWith(prefix)) return;
    if (message.content.startsWith(prefix + "atlas")) {
        if(message.channel.id != mychannel) return;
        let random = Math.floor(Math.random() * replies.length);
        //message.channel.send(replies[random]);
        message.channel.send(replies[random]);
    } 

  });



client.login(config.token);